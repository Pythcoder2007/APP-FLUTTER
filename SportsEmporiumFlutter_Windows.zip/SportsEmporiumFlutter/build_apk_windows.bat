@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo =====================================================
echo   Sports Emporium - Windows APK Builder

echo   No Ubuntu or WSL is used.
echo =====================================================
echo.

where flutter >nul 2>nul
if errorlevel 1 (
  echo ERROR: Flutter is not installed or is not in PATH.
  echo.
  echo Install Flutter for Windows and Android Studio first:
  echo https://docs.flutter.dev/get-started/install/windows/mobile
  echo.
  pause
  exit /b 1
)

echo [1/5] Checking Flutter...
call flutter doctor
if errorlevel 1 (
  echo.
  echo Flutter doctor found a setup problem. Fix the red items above.
  pause
  exit /b 1
)

if not exist "android\app\build.gradle" if not exist "android\app\build.gradle.kts" (
  echo.
  echo [2/5] Creating Android platform files...
  if exist ".platform_temp" rmdir /s /q ".platform_temp"
  call flutter create --platforms=android --org com.shrishakra --project-name sports_emporium_manager .platform_temp
  if errorlevel 1 goto :failed
  xcopy ".platform_temp\android" "android" /E /I /H /Y >nul
  if exist ".platform_temp\.metadata" copy /Y ".platform_temp\.metadata" ".metadata" >nul
  rmdir /s /q ".platform_temp"
) else (
  echo [2/5] Android platform files already exist.
)

echo [3/5] Downloading Flutter packages...
call flutter pub get
if errorlevel 1 goto :failed

echo [4/5] Building release APK...
call flutter build apk --release
if errorlevel 1 goto :failed

echo [5/5] Copying APK to project folder...
if not exist "APK_OUTPUT" mkdir "APK_OUTPUT"
copy /Y "build\app\outputs\flutter-apk\app-release.apk" "APK_OUTPUT\SportsEmporium-release.apk" >nul

echo.
echo =====================================================
echo SUCCESS

echo APK: %CD%\APK_OUTPUT\SportsEmporium-release.apk
echo =====================================================
explorer "APK_OUTPUT"
pause
exit /b 0

:failed
echo.
echo BUILD FAILED. Read the error above.
pause
exit /b 1
