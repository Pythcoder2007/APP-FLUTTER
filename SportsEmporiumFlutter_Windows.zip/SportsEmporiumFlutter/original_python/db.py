"""
db.py - Database layer for Sports Emporium Manager
Handles all SQLite schema creation and data access.
"""
import sqlite3
import os
import sys
from datetime import datetime

def _dir_is_writable(path):
    try:
        os.makedirs(path, exist_ok=True)
        test_file = os.path.join(path, ".write_test")
        with open(test_file, "w") as f:
            f.write("ok")
        os.remove(test_file)
        return True
    except Exception:
        return False


def get_db_path():
    """Store the database next to the exe/script so data persists between runs.
    If that folder isn't writable (e.g. the exe was installed under
    Program Files, or run from a read-only/AV-locked location), fall back
    to a per-user app-data folder so saving never silently fails."""
    if getattr(sys, 'frozen', False):
        base_dir = os.path.dirname(sys.executable)
    else:
        base_dir = os.path.dirname(os.path.abspath(__file__))

    if _dir_is_writable(base_dir):
        return os.path.join(base_dir, "sports_emporium.db")

    # Fallback: a folder we always have permission to write to.
    fallback_root = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or os.path.expanduser("~")
    fallback_dir = os.path.join(fallback_root, "SportsEmporium")
    os.makedirs(fallback_dir, exist_ok=True)
    return os.path.join(fallback_dir, "sports_emporium.db")


DB_PATH = get_db_path()


def set_db_path(path):
    """Override where the SQLite file lives. Call this BEFORE init_db().
    Used on Android to point at the app's private, writable data directory."""
    global DB_PATH
    DB_PATH = path


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sku TEXT UNIQUE,
            name TEXT NOT NULL,
            category TEXT,
            cost_price REAL DEFAULT 0,
            sell_price REAL NOT NULL,
            quantity INTEGER DEFAULT 0,
            low_stock_threshold INTEGER DEFAULT 5,
            created_at TEXT DEFAULT (datetime('now'))
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT,
            total_spent REAL DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now'))
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS sales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_no TEXT UNIQUE,
            customer_id INTEGER,
            sale_date TEXT DEFAULT (datetime('now')),
            subtotal REAL NOT NULL,
            discount REAL DEFAULT 0,
            tax REAL DEFAULT 0,
            total REAL NOT NULL,
            payment_method TEXT DEFAULT 'Cash',
            FOREIGN KEY (customer_id) REFERENCES customers(id)
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS sale_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sale_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            product_name TEXT NOT NULL,
            unit_price REAL NOT NULL,
            quantity INTEGER NOT NULL,
            line_total REAL NOT NULL,
            FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(id)
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)

    defaults = {
        "shop_name": "My Sports Emporium",
        "shop_address": "",
        "shop_phone": "",
        "tax_rate": "5",
        "currency_symbol": "Rs.",
        "next_invoice_no": "1001"
    }
    for k, v in defaults.items():
        c.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))

    conn.commit()
    conn.close()


# ---------- Settings ----------
def get_setting(key, default=""):
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    conn.close()
    return row["value"] if row else default


def set_setting(key, value):
    conn = get_connection()
    conn.execute("INSERT INTO settings (key, value) VALUES (?, ?) "
                 "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
    conn.commit()
    conn.close()


def get_next_invoice_no():
    n = int(get_setting("next_invoice_no", "1001"))
    set_setting("next_invoice_no", str(n + 1))
    return f"INV-{n}"


# ---------- Products / Inventory ----------
def add_product(sku, name, category, cost_price, sell_price, quantity, low_stock_threshold):
    conn = get_connection()
    conn.execute("""INSERT INTO products (sku, name, category, cost_price, sell_price, quantity, low_stock_threshold)
                     VALUES (?, ?, ?, ?, ?, ?, ?)""",
                 (sku, name, category, cost_price, sell_price, quantity, low_stock_threshold))
    conn.commit()
    conn.close()


def update_product(product_id, sku, name, category, cost_price, sell_price, quantity, low_stock_threshold):
    conn = get_connection()
    conn.execute("""UPDATE products SET sku=?, name=?, category=?, cost_price=?, sell_price=?,
                     quantity=?, low_stock_threshold=? WHERE id=?""",
                 (sku, name, category, cost_price, sell_price, quantity, low_stock_threshold, product_id))
    conn.commit()
    conn.close()


def delete_product(product_id):
    conn = get_connection()
    conn.execute("DELETE FROM products WHERE id=?", (product_id,))
    conn.commit()
    conn.close()


def get_all_products(search_term=None):
    conn = get_connection()
    if search_term:
        like = f"%{search_term}%"
        rows = conn.execute(
            "SELECT * FROM products WHERE name LIKE ? OR sku LIKE ? OR category LIKE ? ORDER BY name",
            (like, like, like)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM products ORDER BY name").fetchall()
    conn.close()
    return rows


def get_product(product_id):
    conn = get_connection()
    row = conn.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()
    conn.close()
    return row


def adjust_stock(product_id, delta):
    """delta positive = restock, negative = sale deduction"""
    conn = get_connection()
    conn.execute("UPDATE products SET quantity = quantity + ? WHERE id=?", (delta, product_id))
    conn.commit()
    conn.close()


def get_low_stock_products():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM products WHERE quantity <= low_stock_threshold ORDER BY quantity ASC").fetchall()
    conn.close()
    return rows


def get_distinct_categories():
    conn = get_connection()
    rows = conn.execute("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != '' ORDER BY category").fetchall()
    conn.close()
    return [r["category"] for r in rows]


# ---------- Customers ----------
def get_or_create_customer(name, phone):
    if not name:
        return None
    conn = get_connection()
    row = conn.execute("SELECT * FROM customers WHERE name=? AND phone=?", (name, phone)).fetchone()
    if row:
        conn.close()
        return row["id"]
    cur = conn.execute("INSERT INTO customers (name, phone) VALUES (?, ?)", (name, phone))
    conn.commit()
    cid = cur.lastrowid
    conn.close()
    return cid


def get_all_customers(search_term=None):
    conn = get_connection()
    if search_term:
        like = f"%{search_term}%"
        rows = conn.execute("SELECT * FROM customers WHERE name LIKE ? OR phone LIKE ? ORDER BY total_spent DESC",
                             (like, like)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM customers ORDER BY total_spent DESC").fetchall()
    conn.close()
    return rows


# ---------- Sales / Billing ----------
def create_sale(cart_items, discount, tax, customer_name=None, customer_phone=None, payment_method="Cash"):
    """
    cart_items: list of dicts {product_id, product_name, unit_price, quantity}
    Returns invoice_no
    """
    conn = get_connection()
    c = conn.cursor()

    subtotal = sum(item["unit_price"] * item["quantity"] for item in cart_items)
    total = subtotal - discount + tax

    invoice_no = get_next_invoice_no()
    customer_id = get_or_create_customer(customer_name, customer_phone) if customer_name else None

    c.execute("""INSERT INTO sales (invoice_no, customer_id, subtotal, discount, tax, total, payment_method)
                 VALUES (?, ?, ?, ?, ?, ?, ?)""",
              (invoice_no, customer_id, subtotal, discount, tax, total, payment_method))
    sale_id = c.lastrowid

    for item in cart_items:
        line_total = item["unit_price"] * item["quantity"]
        c.execute("""INSERT INTO sale_items (sale_id, product_id, product_name, unit_price, quantity, line_total)
                     VALUES (?, ?, ?, ?, ?, ?)""",
                  (sale_id, item["product_id"], item["product_name"], item["unit_price"],
                   item["quantity"], line_total))
        c.execute("UPDATE products SET quantity = quantity - ? WHERE id=?", (item["quantity"], item["product_id"]))

    if customer_id:
        c.execute("UPDATE customers SET total_spent = total_spent + ? WHERE id=?", (total, customer_id))

    conn.commit()
    conn.close()
    return invoice_no, sale_id, total


def get_sale_with_items(sale_id):
    conn = get_connection()
    sale = conn.execute("SELECT * FROM sales WHERE id=?", (sale_id,)).fetchone()
    items = conn.execute("SELECT * FROM sale_items WHERE sale_id=?", (sale_id,)).fetchall()
    conn.close()
    return sale, items


def get_recent_sales(limit=50):
    conn = get_connection()
    rows = conn.execute("SELECT * FROM sales ORDER BY sale_date DESC LIMIT ?", (limit,)).fetchall()
    conn.close()
    return rows


# ---------- Revenue Reports ----------
def revenue_today():
    conn = get_connection()
    row = conn.execute("SELECT COALESCE(SUM(total),0) AS total, COUNT(*) AS cnt FROM sales WHERE date(sale_date) = date('now')").fetchone()
    conn.close()
    return row["total"], row["cnt"]


def revenue_this_month():
    conn = get_connection()
    row = conn.execute("""SELECT COALESCE(SUM(total),0) AS total, COUNT(*) AS cnt FROM sales
                           WHERE strftime('%Y-%m', sale_date) = strftime('%Y-%m', 'now')""").fetchone()
    conn.close()
    return row["total"], row["cnt"]


def revenue_this_year():
    conn = get_connection()
    row = conn.execute("""SELECT COALESCE(SUM(total),0) AS total, COUNT(*) AS cnt FROM sales
                           WHERE strftime('%Y', sale_date) = strftime('%Y', 'now')""").fetchone()
    conn.close()
    return row["total"], row["cnt"]


def revenue_by_day(days=14):
    conn = get_connection()
    rows = conn.execute("""
        SELECT date(sale_date) AS day, COALESCE(SUM(total),0) AS total
        FROM sales
        WHERE date(sale_date) >= date('now', ?)
        GROUP BY date(sale_date)
        ORDER BY day
    """, (f'-{days} days',)).fetchall()
    conn.close()
    return rows


def revenue_by_month(months=12):
    conn = get_connection()
    rows = conn.execute("""
        SELECT strftime('%Y-%m', sale_date) AS month, COALESCE(SUM(total),0) AS total
        FROM sales
        WHERE sale_date >= date('now', ?)
        GROUP BY month
        ORDER BY month
    """, (f'-{months} months',)).fetchall()
    conn.close()
    return rows


def revenue_by_year():
    conn = get_connection()
    rows = conn.execute("""
        SELECT strftime('%Y', sale_date) AS year, COALESCE(SUM(total),0) AS total
        FROM sales
        GROUP BY year
        ORDER BY year
    """).fetchall()
    conn.close()
    return rows


def top_selling_products(limit=10, period_days=None):
    conn = get_connection()
    if period_days:
        rows = conn.execute("""
            SELECT si.product_name, SUM(si.quantity) AS qty_sold, SUM(si.line_total) AS revenue
            FROM sale_items si JOIN sales s ON si.sale_id = s.id
            WHERE date(s.sale_date) >= date('now', ?)
            GROUP BY si.product_name ORDER BY qty_sold DESC LIMIT ?
        """, (f'-{period_days} days', limit)).fetchall()
    else:
        rows = conn.execute("""
            SELECT product_name, SUM(quantity) AS qty_sold, SUM(line_total) AS revenue
            FROM sale_items GROUP BY product_name ORDER BY qty_sold DESC LIMIT ?
        """, (limit,)).fetchall()
    conn.close()
    return rows


def profit_summary():
    """Rough profit = sum(line_total) - sum(cost_price * qty) using current cost prices."""
    conn = get_connection()
    row = conn.execute("""
        SELECT COALESCE(SUM(si.line_total),0) AS revenue,
               COALESCE(SUM(p.cost_price * si.quantity),0) AS cost
        FROM sale_items si LEFT JOIN products p ON si.product_id = p.id
    """).fetchone()
    conn.close()
    return row["revenue"], row["cost"], row["revenue"] - row["cost"]
